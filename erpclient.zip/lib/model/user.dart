class User {
  final String id;
  final String name;
  final String fullname;
  final String role;
  final String rol;
  final String compCode;
  final String branchCode;
  final String locCode;

  User(
      {this.id,
      this.name,
      this.fullname,
      this.role,
      this.rol,
      this.compCode,
      this.branchCode,
      this.locCode});
}